create function actual_date() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
        NEW.DATE_OF_RECEIPT = now();
        RETURN NEW;
    END;
$$;

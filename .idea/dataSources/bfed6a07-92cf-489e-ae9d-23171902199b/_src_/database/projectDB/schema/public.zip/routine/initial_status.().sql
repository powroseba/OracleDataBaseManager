create function initial_status() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
        NEW.STATUS = 'INPROGRESS';
        RETURN NEW;
    END;
$$;
